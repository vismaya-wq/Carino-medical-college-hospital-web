globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ZNJkELq4_wrrJqE67UDNF/_buildManifest.js",
    "static/ZNJkELq4_wrrJqE67UDNF/_ssgManifest.js",
    "static/ZNJkELq4_wrrJqE67UDNF/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1ckvzn7sfprko.js",
    "static/chunks/06bs-nf19b2js.js",
    "static/chunks/03qr0cg---ut6.js",
    "static/chunks/3l_qmp-61z4yc.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/03qr0cg---ut6.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/03qr0cg---ut6.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/03qr0cg---ut6.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/03qr0cg---ut6.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/06bs-nf19b2js.js",
        "static/chunks/03qr0cg---ut6.js",
        "static/chunks/3l_qmp-61z4yc.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
